Name: Will Gatlin
Course: CPSC350-03
Due Date: 12/10/2023
Assignment: PA6 - Kruskal's

Files:
input.txt
output.txt
README.txt
WGraph.cpp
WGraph.h    
WGraphMain.cpp


Execute: 
g++ *.cpp -o e.exe
./e.exe

Application Purpose:
Using Kruskal's Algorithm to find the minimum spanding tree of a graph.

Sources:
https://stackoverflow.com/questions/19053903/why-output-showing-0-instead-of-0-0 


