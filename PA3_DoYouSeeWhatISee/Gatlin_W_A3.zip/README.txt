Name: Will Gatlin
Course: CPSC350-03
Due Date: 10/17/23
Assignment: PA3 - Do You See What I See?

Files:
input.txt
main.cpp
MonoStack.h
output.txt
README.txt
SpeakerView.cpp
SpeakerView.h

Execute:
g++ *.cpp -o e.exe
./e.exe input.txt output.txt

Application Purpose:
Determine how many people in an audience can see based off their heights using stack ADTs

Sources:
geeksforgeeks.org
stackoverflow.come
w3schools.com
