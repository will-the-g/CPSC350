Name: Will Gatlin
Course: CPSC350-03
Due Date: 11/01/2023
Assignment: PA4 - Genetic Palindromes

Files:
DblList.h
DNASeq.cpp
DNASeq.h
input.txt
ListNode.h
main.cpp
PalindromeFinder.cpp
PalindromeFinder.h
README.txt


Execute: 
g++ *.cpp -o e.exe
./e.exe input.txt

Application Purpose:
Using doubly linked list to represent strands of dna to find if it, or any substring > 5 of it, is a palindrome.

Sources:
geeksforgeeks.com

