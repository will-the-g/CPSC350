#ifndef PALINDROME_FINDER_H
#define PALINDROME_FINDER_H
#include "DNASeq.h"
#include "DblList.h"
#include <iostream>
using namespace std;

class PalindromeFinder{
    public:
        PalindromeFinder();
        ~PalindromeFinder();
        void findPalindromes(DNASeq* input);


    private:


};

#endif
