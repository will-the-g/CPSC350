Name: Will Gatlin
Course: CPSC350-03
Due Date: 09/26/23
Assignment: PA2 - Not So Super Mario Bros

Files:
fileProcessor.cpp
fileProcessor.h
input.txt
level.cpp
level.h
log.txt
main.cpp
mario.cpp
mario.how
README.txt
world.cpp
world.h

Execute:
g++ *.cpp -o main.exe
./main.exe input.txt log.txt

Application Purpose:
Simulate a super mario bros game without graphics by outputting the status and each action of mario to an output file.

Sources:
geeksforgeeks.org
stackoverflow.com
w3schools.com
