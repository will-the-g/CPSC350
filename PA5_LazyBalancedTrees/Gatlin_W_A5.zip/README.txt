Name: Will Gatlin
Course: CPSC350-03
Due Date: 11/30/2023
Assignment: PA5 - Lazy BST

Files:
BST.h
faculty.cpp
faculty.h
main.cpp
README.txt
student.cpp
student.h
TreeNode.h


Execute: 
g++ *.cpp -o main.exe
./main.exe

Application Purpose:
Using a lazy self balancing binary search tree as a database to store students and faculty, and their information.

Sources:
geeksforgeeks.com
stackoverflow.com
https://www.geeksforgeeks.org/cpp-binary-search/
https://stackoverflow.com/questions/10575766/comparison-operator-overloading


