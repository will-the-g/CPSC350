Name: Will Gatlin
Course: CPSC350-03
Due Date: 09/12/2023
Assignment: PA1 - Robber Language Translation

Files:
Main.cpp
model.h
model.cpp
translator.h
translator.cpp
FileProcessor.h
FileProcessor.cpp
input.txt
output.html
README.txt

Execute:
g++ main.cpp -o main.exe 
./main.exe input.txt output.html

Application Purpose: 
This program is able to transfer regular english into robber language or Rövarspråket, while keeping spaces and punctuation.

Sources:
https://stackoverflow.com/questions/10532384/how-to-remove-a-particular-substring-from-a-string 
https://www.geeksforgeeks.org/how-to-convert-a-single-character-to-string-in-cpp/ 
